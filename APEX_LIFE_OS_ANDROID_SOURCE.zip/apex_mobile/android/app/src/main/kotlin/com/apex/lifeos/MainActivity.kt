package com.apex.lifeos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
