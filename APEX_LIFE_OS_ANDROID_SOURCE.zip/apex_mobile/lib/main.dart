import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:shamsi_date/shamsi_date.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.database;
  runApp(const ApexApp());
}

const ink = Color(0xFF172033);
const violet = Color(0xFF6957D8);
const canvas = Color(0xFFF5F6FA);

class ApexApp extends StatelessWidget {
  const ApexApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'APEX LIFE OS',
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(seedColor: violet, brightness: Brightness.light),
          appBarTheme: const AppBarTheme(backgroundColor: canvas, foregroundColor: ink, centerTitle: false),
          cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: const Color(0xFFF4F5FA),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          ),
        ),
        builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const HomeShell(),
      );
}

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(p.join(root, 'apex_life_os.db'), version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE profile(id INTEGER PRIMARY KEY CHECK(id=1), name TEXT NOT NULL DEFAULT 'دوست من', sleep_time TEXT, wake_time TEXT, personality TEXT)''');
      await db.insert('profile', {'id': 1, 'name': 'دوست من'});
      await db.execute('''CREATE TABLE habits(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, best_streak INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE habit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, habit_id INTEGER NOT NULL, log_date TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 1, UNIQUE(habit_id, log_date), FOREIGN KEY(habit_id) REFERENCES habits(id) ON DELETE CASCADE)''');
      await db.execute('''CREATE TABLE activities(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'عمومی', activity_date TEXT NOT NULL, activity_time TEXT, done INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, deadline TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE checkins(id INTEGER PRIMARY KEY AUTOINCREMENT, checkin_date TEXT NOT NULL UNIQUE, mood INTEGER NOT NULL, energy INTEGER NOT NULL, note TEXT)''');
      await db.execute('''CREATE TABLE sleep_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, sleep_date TEXT NOT NULL, sleep_time TEXT, wake_time TEXT, hours REAL)''');
      await db.execute('''CREATE TABLE stats(id INTEGER PRIMARY KEY CHECK(id=1), xp INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 1)''');
      await db.insert('stats', {'id': 1, 'xp': 0, 'level': 1});
      await db.execute('''CREATE TABLE achievements(id INTEGER PRIMARY KEY AUTOINCREMENT, achievement_key TEXT NOT NULL UNIQUE, unlocked_at TEXT NOT NULL)''');
      await db.execute('CREATE INDEX idx_activity_date ON activities(activity_date)');
      await db.execute('CREATE INDEX idx_habit_log_date ON habit_logs(log_date)');
    });
    await _db!.execute('PRAGMA foreign_keys = ON');
    return _db!;
  }
  Future<List<Map<String, Object?>>> query(String sql, [List<Object?> args = const []]) async => (await database).rawQuery(sql, args);
  Future<int> insert(String table, Map<String, Object?> values) async => (await database).insert(table, values);
  Future<int> update(String table, Map<String, Object?> values, String where, List<Object?> args) async => (await database).update(table, values, where: where, whereArgs: args);
  Future<int> delete(String table, String where, List<Object?> args) async => (await database).delete(table, where: where, whereArgs: args);
  Future<void> xp(int delta) async {
    final db = await database;
    await db.rawUpdate('UPDATE stats SET xp=MAX(0,xp+?), level=CAST(MAX(0,xp+?)/1000 AS INTEGER)+1 WHERE id=1', [delta, delta]);
    final current = await db.rawQuery('SELECT xp FROM stats WHERE id=1');
    if ((current.first['xp'] as int) >= 1000) {
      await db.insert('achievements', {'achievement_key': 'xp_1000', 'unlocked_at': DateTime.now().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }
  Future<int> getXp() async => ((await query('SELECT xp FROM stats WHERE id=1')).first['xp'] as int?) ?? 0;
  Future<void> achievement(String key) async {
    final db = await database;
    await db.insert('achievements', {'achievement_key': key, 'unlocked_at': DateTime.now().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.ignore);
  }
}

String dayKey([DateTime? value]) {
  final d = value ?? DateTime.now();
  return '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}
String fa(String value) => value.replaceAll('0','۰').replaceAll('1','۱').replaceAll('2','۲').replaceAll('3','۳').replaceAll('4','۴').replaceAll('5','۵').replaceAll('6','۶').replaceAll('7','۷').replaceAll('8','۸').replaceAll('9','۹');
String dateLabel([DateTime? d]) { final x = Jalali.fromDateTime(d ?? DateTime.now()); return fa('${x.year}/${x.month.toString().padLeft(2,'0')}/${x.day.toString().padLeft(2,'0')}'); }

class HomeShell extends StatefulWidget { const HomeShell({super.key}); @override State<HomeShell> createState() => _HomeShellState(); }
class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final pages = const [DashboardPage(), TodayPage(), HabitsPage(), GoalsPage(), MorePage()];
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: IndexedStack(index: index, children: pages)),
    bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [
      NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'خانه'),
      NavigationDestination(icon: Icon(Icons.today_rounded), label: 'امروز'),
      NavigationDestination(icon: Icon(Icons.local_fire_department_rounded), label: 'عادت‌ها'),
      NavigationDestination(icon: Icon(Icons.flag_rounded), label: 'اهداف'),
      NavigationDestination(icon: Icon(Icons.apps_rounded), label: 'بیشتر'),
    ]),
  );
}

class PageTitle extends StatelessWidget { final String title; final String? subtitle; const PageTitle(this.title, {super.key, this.subtitle}); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: ink)), if (subtitle != null) ...[const SizedBox(height: 5), Text(subtitle!, style: TextStyle(color: Colors.blueGrey.shade500))]])); }
class Panel extends StatelessWidget { final Widget child; final EdgeInsets padding; const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(17)}); @override Widget build(BuildContext context) => Card(child: Padding(padding: padding, child: child)); }
class ProgressLine extends StatelessWidget { final int value; const ProgressLine(this.value, {super.key}); @override Widget build(BuildContext context) => ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: value.clamp(0,100)/100, minHeight: 9, backgroundColor: const Color(0xFFE9EAF2), color: violet)); }
Widget sectionTitle(String text, {Widget? trailing}) => Padding(padding: const EdgeInsets.fromLTRB(4, 18, 4, 9), child: Row(children: [Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: ink))), if (trailing != null) trailing]));

class DashboardPage extends StatefulWidget { const DashboardPage({super.key}); @override State<DashboardPage> createState() => _DashboardPageState(); }
class _DashboardPageState extends State<DashboardPage> {
  Future<Map<String, Object?>> load() async {
    final db = AppDb.instance;
    final a = (await db.query('SELECT COUNT(*) total, COALESCE(SUM(done),0) done FROM activities WHERE activity_date=?', [dayKey()])).first;
    final h = (await db.query('SELECT COUNT(*) total FROM habits WHERE active=1')).first;
    final hd = (await db.query('SELECT COUNT(*) total FROM habit_logs l JOIN habits h ON h.id=l.habit_id WHERE l.log_date=? AND l.done=1 AND h.active=1', [dayKey()])).first;
    final g = (await db.query('SELECT COUNT(*) total, COALESCE(AVG(progress),0) avg FROM goals')).first;
    final c = await db.query('SELECT mood,energy FROM checkins WHERE checkin_date=?', [dayKey()]);
    final xp = (await db.query('SELECT xp,level FROM stats WHERE id=1')).first;
    final ac = (await db.query('SELECT COUNT(*) total FROM achievements')).first;
    final at = (a['total'] as int); final ad = (a['done'] as int); final ht = h['total'] as int; final hdv = hd['total'] as int;
    final ap = at == 0 ? 0 : (ad * 100 / at).round(); final hp = ht == 0 ? 0 : (hdv * 100 / ht).round();
    final mood = c.isEmpty ? 0 : c.first['mood'] as int; final energy = c.isEmpty ? 0 : c.first['energy'] as int;
    final gp = (g['avg'] as num).round();
    final score = ((ap + hp + gp + mood * 10 + energy * 10) / 5).round();
    return {'score':score,'activity':ap,'habit':hp,'goals':g['total'],'goalAvg':gp,'mood':mood,'energy':energy,'xp':xp['xp'],'level':xp['level'],'achievements':ac['total'],'done':ad,'total':at,'habitDone':hdv,'habitTotal':ht};
  }
  @override Widget build(BuildContext context) => FutureBuilder<Map<String,Object?>>(future: load(), builder: (context,s) {
    if (!s.hasData) return const Center(child:CircularProgressIndicator()); final d=s.data!;
    return RefreshIndicator(onRefresh: () async => setState((){}), child: ListView(padding: const EdgeInsets.fromLTRB(16,8,16,22), children: [
      const PageTitle('APEX LIFE OS', subtitle:'هر روز، یک قدم بهتر'),
      Panel(child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[Row(children:[const Expanded(child:Text('امتیاز امروز',style:TextStyle(fontWeight:FontWeight.w700,fontSize:16))),Text('${fa('${d['score']}')}/۱۰۰',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900,color:violet))]), const SizedBox(height:12), ProgressLine(d['score'] as int), const SizedBox(height:12), Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('سطح ${fa('${d['level']}')}',style:const TextStyle(fontWeight:FontWeight.bold)),Text('${fa('${d['xp']}')} XP'),Text('🏅 ${fa('${d['achievements']}')} دستاورد')])])),
      sectionTitle('خلاصه عملکرد'), GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.65,children:[_metric('📋','فعالیت‌ها','${d['done']}/${d['total']}',d['activity'] as int),_metric('🔥','عادت‌ها','${d['habitDone']}/${d['habitTotal']}',d['habit'] as int),_metric('🎯','میانگین اهداف','${d['goalAvg']}%',d['goalAvg'] as int),_metric('🧠','حال و انرژی','${d['mood']}/10 • ${d['energy']}/10',0)]),
      sectionTitle('دسترسی سریع'), Wrap(spacing:8,runSpacing:8,children:[_quick(context,'ثبت حال من',Icons.mood,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CheckinPage())).then((_)=>setState((){}))),_quick(context,'ثبت خواب',Icons.bedtime,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SleepPage()))),_quick(context,'گزارش هفتگی',Icons.bar_chart,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const WeeklyPage()))),_quick(context,'مربی APEX',Icons.psychology,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CoachPage()))) ]),
      const SizedBox(height:12), const Text('پیشرفت با استمرار ساخته می‌شود 🌱',textAlign:TextAlign.center,style:TextStyle(color:Colors.blueGrey,fontWeight:FontWeight.w600)),
    ]));
  });
  Widget _metric(String icon,String title,String value,int percent)=>Panel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(icon,style:const TextStyle(fontSize:20)),Text(title,style:const TextStyle(color:Colors.blueGrey)),Text(value,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),if(percent>0)ProgressLine(percent)]));
  Widget _quick(BuildContext c,String label,IconData icon,{required VoidCallback onTap})=>ActionChip(avatar:Icon(icon,size:18,color:violet),label:Text(label),onPressed:onTap,backgroundColor:Colors.white,side:BorderSide.none);
}

class TodayPage extends StatefulWidget { const TodayPage({super.key}); @override State<TodayPage> createState()=>_TodayPageState(); }
class _TodayPageState extends State<TodayPage> {
  Future<List<Map<String,Object?>>> load()=>AppDb.instance.query('SELECT * FROM activities WHERE activity_date=? ORDER BY CASE WHEN activity_time IS NULL THEN 1 ELSE 0 END, activity_time', [dayKey()]);
  Future<void> add() async { final title=TextEditingController(); final time=TextEditingController(); final category=ValueNotifier('عمومی'); final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('فعالیت جدید'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'عنوان فعالیت')),const SizedBox(height:10),TextField(controller:time,decoration:const InputDecoration(labelText:'ساعت (اختیاری، مثل 18:30)')),const SizedBox(height:10),ValueListenableBuilder(valueListenable:category,builder:(_,v,__)=>DropdownButtonFormField<String>(value:v,decoration:const InputDecoration(labelText:'دسته‌بندی'),items:['عمومی','ورزش','مطالعه','کار','یادگیری'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>category.value=x??'عمومی'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('انصراف')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('ثبت'))]));
    if(ok==true && title.text.trim().isNotEmpty){ final t=time.text.trim(); if(t.isNotEmpty && !RegExp(r'^([01]\d|2[0-3]):[0-5]\d$').hasMatch(t)){if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('فرمت ساعت باید مثل 18:30 باشد')));return;} await AppDb.instance.insert('activities',{'title':title.text.trim(),'category':category.value,'activity_date':dayKey(),'activity_time':t.isEmpty?null:t,'created_at':DateTime.now().toIso8601String()}); setState((){}); } }
  Future<void> toggle(Map<String,Object?> item) async { final next=(item['done'] as int)==1?0:1; await AppDb.instance.update('activities',{'done':next},'id=?',[item['id']]); await AppDb.instance.xp(next==1?15:-15); if(mounted)setState((){}); }
  @override Widget build(BuildContext context)=>Column(children:[const PageTitle('برنامه امروز',subtitle:'فعالیت‌هایت را ثبت و پیگیری کن'),Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Row(children:[Expanded(child:Text(dateLabel(),style:const TextStyle(color:Colors.blueGrey))),FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('فعالیت جدید'))])),Expanded(child:FutureBuilder<List<Map<String,Object?>>>(future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.isEmpty)return const _Empty(icon:Icons.event_note,title:'برنامه‌ای ثبت نشده',hint:'اولین فعالیت امروزت را اضافه کن');return ListView.builder(padding:const EdgeInsets.all(16),itemCount:s.data!.length,itemBuilder:(c,i){final x=s.data![i];final done=x['done']==1;return Panel(child:Row(children:[IconButton(onPressed:()=>toggle(x),icon:Icon(done?Icons.check_circle:Icons.radio_button_unchecked,color:done?Colors.green:violet)),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(x['title'] as String,style:TextStyle(fontWeight:FontWeight.bold,decoration:done?TextDecoration.lineThrough:null)),Text('${x['category']} • ${x['activity_time']??'بدون ساعت'}',style:const TextStyle(color:Colors.blueGrey,fontSize:12))])),IconButton(onPressed:()async{if(x['done']==1)await AppDb.instance.xp(-15);await AppDb.instance.delete('activities','id=?',[x['id']]);setState((){});},icon:const Icon(Icons.delete_outline,color:Colors.redAccent))]));});}))]);
}

class HabitsPage extends StatefulWidget { const HabitsPage({super.key}); @override State<HabitsPage> createState()=>_HabitsPageState(); }
class _HabitsPageState extends State<HabitsPage>{
 Future<List<Map<String,Object?>>> load()=>AppDb.instance.query('SELECT h.*, (SELECT done FROM habit_logs l WHERE l.habit_id=h.id AND l.log_date=?) today_done FROM habits h WHERE h.active=1 ORDER BY h.id DESC',[dayKey()]);
 Future<void> add()async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(title:const Text('ساخت عادت'),content:TextField(controller:c,autofocus:true,decoration:const InputDecoration(hintText:'مثلاً مطالعه روزانه')),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('انصراف')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('ثبت عادت'))]));if(ok==true&&c.text.trim().isNotEmpty){await AppDb.instance.insert('habits',{'name':c.text.trim(),'created_at':DateTime.now().toIso8601String()});setState((){});}}
 Future<int> streak(int id)async{final rows=await AppDb.instance.query('SELECT log_date FROM habit_logs WHERE habit_id=? AND done=1 ORDER BY log_date DESC',[id]);var expected=DateTime.now();int n=0;for(final r in rows){final d=DateTime.tryParse(r['log_date'] as String);if(d==null)continue;if(dayKey(d)==dayKey(expected)){n++;expected=expected.subtract(const Duration(days:1));}else if(dayKey(d)==dayKey(expected.subtract(const Duration(days:1)))&&n==0){expected=expected.subtract(const Duration(days:1));n++;}else{break;}}return n;}
 Future<void> toggle(Map<String,Object?> h)async{final id=h['id'] as int;final done=h['today_done']==1;final db=AppDb.instance;if(done){await db.update('habit_logs',{'done':0},'habit_id=? AND log_date=?',[id,dayKey()]);await db.xp(-20);}else{final rawDb=await db.database;await rawDb.insert('habit_logs',{'habit_id':id,'log_date':dayKey(),'done':1},conflictAlgorithm:ConflictAlgorithm.replace);await db.xp(20);await db.achievement('first_habit');final s=await streak(id);await db.update('habits',{'best_streak':s},'id=? AND best_streak<?',[id,s]);if(s>=3)await db.achievement('streak_3');if(s>=7)await db.achievement('streak_7');if(s>=30)await db.achievement('streak_30');}if(mounted)setState((){});}
 @override Widget build(BuildContext context)=>Column(children:[PageTitle('عادت‌های من',subtitle:'تداوم مهم‌تر از کامل بودن است'),Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Align(alignment:Alignment.centerLeft,child:FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('ساخت عادت')))),Expanded(child:FutureBuilder<List<Map<String,Object?>>>(future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.isEmpty)return const _Empty(icon:Icons.local_fire_department,title:'هنوز عادتی نداری',hint:'یک عادت کوچک برای شروع بساز');return ListView.builder(padding:const EdgeInsets.all(16),itemCount:s.data!.length,itemBuilder:(c,i){final h=s.data![i];final done=h['today_done']==1;return FutureBuilder<int>(future:streak(h['id'] as int),builder:(c,st)=>Panel(child:Row(children:[IconButton(onPressed:()=>toggle(h),icon:Icon(done?Icons.check_circle:Icons.circle_outlined,color:done?Colors.green:violet,size:30)),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(h['name'] as String,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),Text('🔥 ${fa('${st.data??0}')} روز متوالی  •  رکورد ${fa('${h['best_streak']}')} روز',style:const TextStyle(color:Colors.blueGrey,fontSize:12))])),IconButton(onPressed:()async{await AppDb.instance.update('habits',{'active':0},'id=?',[h['id']]);setState((){});},icon:const Icon(Icons.archive_outlined))])));});}))]);
}

class GoalsPage extends StatefulWidget { const GoalsPage({super.key}); @override State<GoalsPage> createState()=>_GoalsPageState(); }
class _GoalsPageState extends State<GoalsPage>{Future<List<Map<String,Object?>>> load()=>AppDb.instance.query('SELECT * FROM goals WHERE active=1 ORDER BY id DESC');
 Future<void> add()async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(title:const Text('هدف جدید'),content:TextField(controller:c,decoration:const InputDecoration(hintText:'مثلاً یادگیری زبان')),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('انصراف')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('ثبت هدف'))]));if(ok==true&&c.text.trim().isNotEmpty){await AppDb.instance.insert('goals',{'title':c.text.trim(),'created_at':DateTime.now().toIso8601String()});setState((){});}}
 Future<void> progress(Map<String,Object?> g,{bool complete=false})async{final old=g['progress'] as int;final v=complete?100:(old+10).clamp(0,100);await AppDb.instance.update('goals',{'progress':v,'active':v>=100?0:1},'id=?',[g['id']]);await AppDb.instance.xp(30);if(v==100){await AppDb.instance.achievement('first_goal');final xp=await AppDb.instance.getXp();if(xp>=1000)await AppDb.instance.achievement('xp_1000');}if(mounted)setState((){});}
 @override Widget build(BuildContext context)=>Column(children:[PageTitle('هدف‌های من',subtitle:'هدف بزرگ را به قدم‌های کوچک تقسیم کن'),Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Align(alignment:Alignment.centerLeft,child:FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('هدف جدید')))),Expanded(child:FutureBuilder<List<Map<String,Object?>>>(future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.isEmpty)return const _Empty(icon:Icons.flag_outlined,title:'هدفی ثبت نشده',hint:'اولین هدف مهمت را بنویس');return ListView.builder(padding:const EdgeInsets.all(16),itemCount:s.data!.length,itemBuilder:(c,i){final g=s.data![i];final v=g['progress'] as int;return Panel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(g['title'] as String,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),const SizedBox(height:12),Row(children:[Expanded(child:ProgressLine(v)),const SizedBox(width:10),Text('$v%',style:const TextStyle(fontWeight:FontWeight.bold))]),const SizedBox(height:12),Row(mainAxisAlignment:MainAxisAlignment.end,children:[TextButton(onPressed:()=>progress(g),child:const Text('+۱۰٪ پیشرفت')),FilledButton.tonal(onPressed:()=>progress(g,complete:true),child:const Text('تکمیل هدف'))]) ]));});}))]);
}

class MorePage extends StatelessWidget { const MorePage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const PageTitle('امکانات بیشتر',subtitle:'ابزارهای تکمیلی APEX'),_menu(context,'گزارش هفتگی','بررسی عملکرد و مقایسه هفته‌ها',Icons.bar_chart, const WeeklyPage()),_menu(context,'خواب','ثبت ساعت خواب و بیداری',Icons.bedtime, const SleepPage()),_menu(context,'حال و انرژی','ثبت وضعیت روزانه',Icons.mood, const CheckinPage()),_menu(context,'مربی هوشمند','پیشنهاد بر اساس عملکرد ثبت‌شده',Icons.psychology,const CoachPage()),_menu(context,'سطح و دستاوردها','XP، سطح و نشان‌های کسب‌شده',Icons.emoji_events,const LevelPage()),_menu(context,'پروفایل','نام و اطلاعات شخصی',Icons.person,const ProfilePage()),_menu(context,'شناخت شخصیت','پرسش‌نامه سبک برنامه‌ریزی',Icons.psychology_alt,const PersonalityPage()),_menu(context,'تقویم فعالیت‌ها','مرور فعالیت‌های روزهای اخیر',Icons.calendar_month,const CalendarPage()),const SizedBox(height:16),const Text('APEX LIFE OS • نسخه ۱.۰',textAlign:TextAlign.center,style:TextStyle(color:Colors.blueGrey))]);
 Widget _menu(BuildContext c,String title,String sub,IconData icon,Widget page)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:const Color(0xFFEDEAFF),child:Icon(icon,color:violet)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(sub),trailing:const Icon(Icons.chevron_left),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>page))));}

class CheckinPage extends StatefulWidget { const CheckinPage({super.key}); @override State<CheckinPage> createState()=>_CheckinPageState(); }
class _CheckinPageState extends State<CheckinPage>{double mood=5,energy=5;final note=TextEditingController();bool loading=true;@override void initState(){super.initState();_load();}Future<void> _load()async{final r=await AppDb.instance.query('SELECT * FROM checkins WHERE checkin_date=?',[dayKey()]);if(r.isNotEmpty){mood=(r.first['mood'] as int).toDouble();energy=(r.first['energy'] as int).toDouble();note.text=(r.first['note'] as String?)??'';}if(mounted)setState(()=>loading=false);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('حال و انرژی')),body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(18),children:[const Text('امروز چه حسی داری؟',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:20),_slider('🧠 حال روحی',mood,(v)=>setState(()=>mood=v)),const SizedBox(height:20),_slider('⚡ انرژی',energy,(v)=>setState(()=>energy=v)),const SizedBox(height:20),TextField(controller:note,maxLines:3,decoration:const InputDecoration(labelText:'یادداشت (اختیاری)',hintText:'امروز چه چیزی روی حالت اثر گذاشت؟')),const SizedBox(height:24),FilledButton(onPressed:()async{final db=AppDb.instance;final old=await db.query('SELECT id FROM checkins WHERE checkin_date=?',[dayKey()]);final data={'checkin_date':dayKey(),'mood':mood.round(),'energy':energy.round(),'note':note.text.trim()};if(old.isEmpty){await db.insert('checkins',data);}else{await db.update('checkins',data,'checkin_date=?',[dayKey()]);}if(context.mounted)Navigator.pop(context);},child:const Text('ذخیره چک‌این'))]));
 Widget _slider(String title,double value,ValueChanged<double> onChanged)=>Panel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17))),Text('${value.round()}/۱۰',style:const TextStyle(color:violet,fontWeight:FontWeight.w900,fontSize:18))]),Slider(value:value,min:1,max:10,divisions:9,onChanged:onChanged),const Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('کم'),Text('زیاد')]) ]));
}

class SleepPage extends StatefulWidget { const SleepPage({super.key}); @override State<SleepPage> createState()=>_SleepPageState(); }
class _SleepPageState extends State<SleepPage>{String? sleep,wake;@override void initState(){super.initState();_load();}Future<void> _load()async{final r=await AppDb.instance.query('SELECT sleep_time,wake_time FROM profile WHERE id=1');if(r.isNotEmpty&&mounted)setState((){sleep=r.first['sleep_time'] as String?;wake=r.first['wake_time'] as String?;});}Future<void> _pick(bool isSleep)async{final t=await showTimePicker(context:context,initialTime:TimeOfDay.now(),builder:(c,w)=>Directionality(textDirection:TextDirection.ltr,child:w!));if(t==null)return;final v='${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}';await AppDb.instance.update('profile',{isSleep?'sleep_time':'wake_time':v},'id=1',[]);if(mounted)setState(()=>isSleep?sleep=v:wake=v);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('برنامه خواب')),body:ListView(padding:const EdgeInsets.all(18),children:[const Text('زمان‌بندی خواب خودت را ثبت کن',style:TextStyle(fontWeight:FontWeight.w900,fontSize:21)),const SizedBox(height:18),Panel(child:ListTile(leading:const Icon(Icons.nightlight_round,color:violet),title:const Text('ساعت خواب'),subtitle:Text(sleep??'ثبت نشده'),trailing:const Icon(Icons.edit),onTap:()=>_pick(true))),Panel(child:ListTile(leading:const Icon(Icons.wb_sunny,color:Colors.orange),title:const Text('ساعت بیداری'),subtitle:Text(wake??'ثبت نشده'),trailing:const Icon(Icons.edit),onTap:()=>_pick(false))),const SizedBox(height:12),const Text('این زمان‌ها برای نمایش در برنامه روزانه استفاده می‌شوند.',style:TextStyle(color:Colors.blueGrey))]));}

class WeeklyPage extends StatelessWidget { const WeeklyPage({super.key}); Future<Map<String,int>> load()async{final db=AppDb.instance;int total=0,done=0,ht=0,hd=0;for(int i=0;i<7;i++){final d=dayKey(DateTime.now().subtract(Duration(days:i)));final a=(await db.query('SELECT COUNT(*) total,COALESCE(SUM(done),0) done FROM activities WHERE activity_date=?',[d])).first;total+=a['total'] as int;done+=a['done'] as int;final h=(await db.query('SELECT COUNT(*) total FROM habits WHERE active=1')).first['total'] as int;final l=(await db.query('SELECT COUNT(*) total FROM habit_logs l JOIN habits h ON h.id=l.habit_id WHERE l.log_date=? AND l.done=1 AND h.active=1',[d])).first['total'] as int;ht+=h;hd+=l;}return {'activityTotal':total,'activityDone':done,'habitTotal':ht,'habitDone':hd};}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('گزارش هفتگی')),body:FutureBuilder<Map<String,int>>(future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final d=s.data!;final ap=d['activityTotal']==0?0:(d['activityDone']!*100/d['activityTotal']!).round();final hp=d['habitTotal']==0?0:(d['habitDone']!*100/d['habitTotal']!).round();return ListView(padding:const EdgeInsets.all(18),children:[Text('۷ روز گذشته • تا ${dateLabel()}',style:const TextStyle(color:Colors.blueGrey)),const SizedBox(height:15),_reportCard('📋 فعالیت‌ها',d['activityDone']!,d['activityTotal']!,ap),_reportCard('🔥 عادت‌ها',d['habitDone']!,d['habitTotal']!,hp),const Panel(child:Text('برای دقیق‌تر شدن گزارش، فعالیت‌ها و عادت‌هایت را هر روز ثبت کن.',style:TextStyle(color:Colors.blueGrey))) ]);}));
 Widget _reportCard(String title,int done,int total,int p)=>Panel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),const SizedBox(height:10),ProgressLine(p),const SizedBox(height:8),Text('$done از $total • $p%',style:const TextStyle(fontWeight:FontWeight.w700))]));}

class CoachPage extends StatelessWidget { const CoachPage({super.key}); Future<List<String>> advice()async{final db=AppDb.instance;final c=await db.query('SELECT mood,energy FROM checkins WHERE checkin_date=?',[dayKey()]);final a=(await db.query('SELECT COUNT(*) total,COALESCE(SUM(done),0) done FROM activities WHERE activity_date=?',[dayKey()])).first;final h=(await db.query('SELECT COUNT(*) total FROM habits WHERE active=1')).first['total'] as int;final hd=(await db.query('SELECT COUNT(*) total FROM habit_logs l JOIN habits h ON h.id=l.habit_id WHERE l.log_date=? AND l.done=1 AND h.active=1',[dayKey()])).first['total'] as int;final out=<String>[];if(c.isEmpty){out.add('🧠 چک‌این امروزت را ثبت کن تا پیشنهاد دقیق‌تری بگیری.');}else{final m=c.first['mood'] as int;final e=c.first['energy'] as int;if(m<=3||e<=3)out.add('🌱 امروز برنامه را سبک‌تر کن و فقط یک کار کوچک و مهم انتخاب کن.');else if(m>=8&&e>=8)out.add('🔥 حال و انرژیت خوب است؛ از این فرصت برای مهم‌ترین اولویتت استفاده کن.');else out.add('⚡ شرایط متعادل است؛ یک کار مهم را انتخاب کن و قدم‌به‌قدم جلو برو.');}if(h>0)out.add(hd==h?'🏆 تمام عادت‌های امروزت انجام شده‌اند.':'🔥 عادت‌ها: $hd از $h انجام شده‌اند؛ یکی را انتخاب کن و انجام بده.');final at=a['total'] as int;out.add(at==0?'📋 هنوز فعالیتی برای امروز ثبت نکرده‌ای.':'📋 فعالیت‌ها: ${a['done']} از $at انجام شده است.');return out;}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('مربی APEX')),body:FutureBuilder<List<String>>(future:advice(),builder:(c,s)=>!s.hasData?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(18),children:[const Text('پیشنهاد امروز',style:TextStyle(fontWeight:FontWeight.w900,fontSize:22)),const SizedBox(height:14),...s.data!.map((x)=>Panel(child:Text(x,style:const TextStyle(fontSize:16,height:1.7)))),const Panel(child:Text('این پیشنهادها بر اساس اطلاعاتی هستند که در اپ ثبت کرده‌ای و جایگزین نظر متخصص نیستند.',style:TextStyle(color:Colors.blueGrey))) ])));}

class LevelPage extends StatelessWidget { const LevelPage({super.key});static const names={'first_habit':'شروع قدرتمند','streak_3':'سه روز متوالی','streak_7':'یک هفته قدرتمند','streak_30':'سی روز متوالی','first_goal':'اولین هدف','xp_1000':'هزار XP'};@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('سطح و دستاوردها')),body:FutureBuilder<List<List<Map<String,Object?>>>>(future:Future.wait([AppDb.instance.query('SELECT xp,level FROM stats WHERE id=1'),AppDb.instance.query('SELECT achievement_key FROM achievements')]),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final stat=s.data![0].first;final keys=s.data![1].map((e)=>e['achievement_key']).toSet();final xp=stat['xp'] as int;final level=stat['level'] as int;final pct=(xp%1000)/10;return ListView(padding:const EdgeInsets.all(18),children:[Panel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('سطح $level',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:25)),Text('$xp XP'),const SizedBox(height:10),ProgressLine(pct.round()),Text('${1000-(xp%1000)} XP تا سطح بعدی') ])),sectionTitle('نشان‌ها'),...names.entries.map((e)=>Panel(child:ListTile(leading:Icon(keys.contains(e.key)?Icons.emoji_events:Icons.lock_outline,color:keys.contains(e.key)?Colors.amber:Colors.blueGrey),title:Text(e.value),subtitle:Text(keys.contains(e.key)?'باز شده':'هنوز باز نشده')))) ]);}));}

class ProfilePage extends StatefulWidget { const ProfilePage({super.key}); @override State<ProfilePage> createState()=>_ProfilePageState(); }
class _ProfilePageState extends State<ProfilePage>{final c=TextEditingController();@override void initState(){super.initState();AppDb.instance.query('SELECT name FROM profile WHERE id=1').then((r){if(r.isNotEmpty&&mounted)setState(()=>c.text=r.first['name'] as String);});}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('پروفایل')),body:ListView(padding:const EdgeInsets.all(18),children:[const Text('نام نمایشی',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),TextField(controller:c,decoration:const InputDecoration(hintText:'نام شما')),const SizedBox(height:18),FilledButton(onPressed:()async{await AppDb.instance.update('profile',{'name':c.text.trim().isEmpty?'دوست من':c.text.trim()},'id=1',[]);if(context.mounted)Navigator.pop(context);},child:const Text('ذخیره تغییرات'))]));}

class PersonalityPage extends StatefulWidget { const PersonalityPage({super.key}); @override State<PersonalityPage> createState()=>_PersonalityPageState(); }
class _PersonalityPageState extends State<PersonalityPage> {
  final answers=<int,int>{};
  final questions=<String>[
    'وقتی هدف مهمی داری، معمولاً چطور شروع می‌کنی؟',
    'کدام نوع برنامه روزانه را ترجیح می‌دهی؟',
    'وقتی انگیزه‌ات کم می‌شود، چه چیزی کمکت می‌کند؟',
    'دوست داری بیشتر روی چه حوزه‌ای کار کنی؟',
    'وقتی از برنامه عقب می‌افتی چه می‌کنی؟',
    'دوست داری APEX چه نقشی برایت داشته باشد؟',
  ];
  final options=<List<String>>[
    ['با هیجان شروع می‌کنم','آرام و منظم جلو می‌روم','تا نتیجه نگیرم رها نمی‌کنم','اول تحلیل و برنامه‌ریزی می‌کنم'],
    ['آزاد و منعطف','مشخص و منظم','فشرده و چالشی','ترکیبی'],
    ['تشویق و انگیزه','برنامه مشخص','دیدن پیشرفت','همراهی دیگران'],
    ['نظم و عادت‌ها','ورزش و تحرک','یادگیری و مهارت','رشد شخصی'],
    ['کمی فاصله می‌گیرم','دوباره برنامه‌ریزی می‌کنم','بیشتر تلاش می‌کنم','علت را بررسی می‌کنم'],
    ['همراه انگیزه‌دهنده','برنامه‌ریز منظم','مربی چالشی','ترکیبی از همه'],
  ];
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('شناخت شخصیت')),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('پاسخ درست یا غلطی وجود ندارد؛ نزدیک‌ترین گزینه به خودت را انتخاب کن.',style:TextStyle(color:Colors.blueGrey)),const SizedBox(height:12),...List.generate(questions.length,(i)=>Panel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('سؤال ${i+1} از ۶',style:const TextStyle(color:violet,fontWeight:FontWeight.bold)),const SizedBox(height:6),Text(questions[i],style:const TextStyle(fontWeight:FontWeight.w800)),...List.generate(4,(j)=>RadioListTile<int>(dense:true,contentPadding:EdgeInsets.zero,title:Text(options[i][j],style:const TextStyle(fontSize:14)),value:j+1,groupValue:answers[i],onChanged:(v)=>setState(()=>answers[i]=v!)))]))),const SizedBox(height:12),FilledButton(onPressed:answers.length==6?()async{final counts=<int,int>{1:0,2:0,3:0,4:0};for(final v in answers.values){counts[v]=(counts[v]??0)+1;}final winner=counts.entries.reduce((a,b)=>a.value>=b.value?a:b).key;const labels={1:'🔥 شروع‌کننده پرانرژی',2:'📋 منظم و برنامه‌محور',3:'🎯 هدف‌محور و پیگیر',4:'🧠 تحلیل‌گر و متفکر'};await AppDb.instance.update('profile',{'personality':labels[winner]},'id=1',[]);if(context.mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('پروفایل تو: ${labels[winner]}')));Navigator.pop(context);}}:null,child:const Text('ثبت نتیجه'))]));
}

class CalendarPage extends StatelessWidget { const CalendarPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('تقویم فعالیت‌ها')),body:FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.query('SELECT activity_date,COUNT(*) total,SUM(done) done FROM activities GROUP BY activity_date ORDER BY activity_date DESC LIMIT 45'),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.isEmpty)return const _Empty(icon:Icons.calendar_month,title:'هنوز فعالیتی ثبت نشده',hint:'فعالیت‌هایت در این صفحه نمایش داده می‌شوند');return ListView(padding:const EdgeInsets.all(16),children:s.data!.map((x){final total=x['total'] as int;final done=(x['done'] as int?)??0;return Panel(child:Row(children:[const Icon(Icons.calendar_today,color:violet),const SizedBox(width:12),Expanded(child:Text(dateLabel(DateTime.parse(x['activity_date'] as String)),style:const TextStyle(fontWeight:FontWeight.bold))),Text('$done از $total',style:const TextStyle(color:Colors.blueGrey))]));}).toList());}));}

class _Empty extends StatelessWidget { final IconData icon;final String title,hint;const _Empty({required this.icon,required this.title,required this.hint});@override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(30),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,size:54,color:Colors.blueGrey.shade200),const SizedBox(height:14),Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:6),Text(hint,textAlign:TextAlign.center,style:const TextStyle(color:Colors.blueGrey))])));}
